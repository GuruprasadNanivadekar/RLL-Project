export class history {
    constructor(
       public userName:string,
    ){}
}